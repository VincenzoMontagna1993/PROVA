using Microsoft.EntityFrameworkCore;
using System;
using System.Security.Cryptography;
using System.Text;

namespace GestionePrenotazioniEventi
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Evento> Eventi { get; set; }
        public DbSet<Prenotazione> Prenotazioni { get; set; }
        public DbSet<User> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Evento>().HasData(
                new Evento { Id = 1, Titolo = "evento1", DataEvento = new DateTime(2025, 12, 15), PostiTotali = 100, PostiDisponibili = 100 },
                new Evento { Id = 2, Titolo = "evento2", DataEvento = new DateTime(2025, 12, 10), PostiTotali = 80, PostiDisponibili = 80 },
                new Evento { Id = 3, Titolo = "evento3", DataEvento = new DateTime(2025, 12, 5), PostiTotali = 50, PostiDisponibili = 50 },
                new Evento { Id = 4, Titolo = "evento4", DataEvento = new DateTime(2025, 12, 5), PostiTotali = 50, PostiDisponibili = 50 },
                new Evento { Id = 5, Titolo = "evento5", DataEvento = new DateTime(2025, 12, 30), PostiTotali = 200, PostiDisponibili = 200 }
                );

            // Inserimento utenti di default
            var password = "montagna";
            var passwordHash = ComputeSha256Hash(password);
            modelBuilder.Entity<User>().HasData(
                new User { Id = 1, Username = "utente1", PasswordHash = passwordHash },
                new User { Id = 2, Username = "utente2", PasswordHash = passwordHash },
                new User { Id = 3, Username = "utente3", PasswordHash = passwordHash }
            );
        }

        private static string ComputeSha256Hash(string rawData)
        {
            using (var sha256 = SHA256.Create())
            {
                var bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(rawData));
                var builder = new StringBuilder();
                foreach (var b in bytes)
                    builder.Append(b.ToString("x2"));
                return builder.ToString();
            }
        }
    }
}