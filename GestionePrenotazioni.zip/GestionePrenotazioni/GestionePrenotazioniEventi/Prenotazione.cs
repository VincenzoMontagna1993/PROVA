using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace GestionePrenotazioniEventi
{
    public class Prenotazione
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Il nome � obbligatorio.")]
        public string Nome { get; set; }

        [Required(ErrorMessage = "Il cognome � obbligatorio.")]
        public string Cognome { get; set; }

        [Required(ErrorMessage = "L'email � obbligatoria.")]
        [EmailAddress(ErrorMessage = "Email non valida.")]
        public string Email { get; set; }
        public string? Telefono { get; set; }

        [Required(ErrorMessage = "Seleziona un evento.")]
        public int EventoId { get; set; }
        public Evento? Evento { get; set; }

        [Range(1, 100, ErrorMessage = "Inserisci un numero di biglietti valido.")]
        public int NumeroBiglietti { get; set; }

        [Required(ErrorMessage = "L'utente � obbligatorio.")]
        public string Utente { get; set; }

        public DateTime DataCreazione { get; set; }
        public string? Stato { get; set; } // "Confermata", "Annullata"
    }
}