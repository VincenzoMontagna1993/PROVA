using System;
using System.Collections.Generic;

namespace GestionePrenotazioniEventi
{
    public class Evento
    {
        public int Id { get; set; }
        public string Titolo { get; set; }
        public DateTime DataEvento { get; set; }
        public int PostiTotali { get; set; }
        public int PostiDisponibili { get; set; }
        public ICollection<Prenotazione> Prenotazioni { get; set; }
    }
}