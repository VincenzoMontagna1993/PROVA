using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace GestionePrenotazioniEventi.Pages.Prenotazioni
{
    public class ListModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        public ListModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public List<Prenotazione> Prenotazioni { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            var username = HttpContext.Session.GetString("Username");
            if (username == null)
                return RedirectToPage("/Login");
            Prenotazioni = await _context.Prenotazioni
                .Include(p => p.Evento)
                .Where(p => p.Utente == username)
                .OrderByDescending(p => p.DataCreazione)
                .ToListAsync();
            return Page();
        }

        public async Task<IActionResult> OnPostAnnullaAsync(int id)
        {
            var pren = await _context.Prenotazioni.Include(p => p.Evento).FirstOrDefaultAsync(p => p.Id == id);
            if (pren != null && pren.Stato == "Confermata")
            {
                pren.Stato = "Annullata";
                if (pren.Evento != null)
                    pren.Evento.PostiDisponibili += pren.NumeroBiglietti;
                await _context.SaveChangesAsync();
            }
            return RedirectToPage();
        }
    }
}
