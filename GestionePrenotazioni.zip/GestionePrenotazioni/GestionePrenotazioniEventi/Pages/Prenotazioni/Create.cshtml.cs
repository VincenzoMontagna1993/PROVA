using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GestionePrenotazioniEventi.Pages.Prenotazioni
{
    public class CreateModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        public CreateModel(ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Prenotazione Prenotazione { get; set; }
        public List<SelectListItem> EventiSelectList { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            if (HttpContext.Session.GetString("Username") == null)
                return RedirectToPage("/Login");
            await LoadEventiAsync();
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            var username = HttpContext.Session.GetString("Username");
            if (username == null)
                return RedirectToPage("/Login");

            // Imposta sempre i campi Utente e Stato PRIMA del controllo ModelState
            Prenotazione.Utente = username;
            Prenotazione.Stato = "Confermata";
            Prenotazione.DataCreazione = System.DateTime.Now;

            if (!ModelState.IsValid)
            {
                await LoadEventiAsync();
                ModelState.AddModelError("Prenotazione.ModelState", "Model State Inserito non valido.");
                return Page();
            }

            var evento = await _context.Eventi.FindAsync(Prenotazione.EventoId);
            if (evento == null || Prenotazione.NumeroBiglietti < 1 || Prenotazione.NumeroBiglietti > evento.PostiDisponibili)
            {
                ModelState.AddModelError("Prenotazione.NumeroBiglietti", "Numero di biglietti non valido o evento non trovato.");
                await LoadEventiAsync();
                return Page();
            }

            evento.PostiDisponibili -= Prenotazione.NumeroBiglietti;
            _context.Prenotazioni.Add(Prenotazione);
            await _context.SaveChangesAsync();
            return RedirectToPage("/Prenotazioni/List");
        }

        private async Task LoadEventiAsync()
        {
            EventiSelectList = await _context.Eventi
                .OrderBy(e => e.DataEvento)
                .Select(e => new SelectListItem
                {
                    Value = e.Id.ToString(),
                    Text = $"{e.Titolo} - {e.DataEvento:dd/MM/yyyy} (Disponibili: {e.PostiDisponibili})"
                })
                .ToListAsync();
        }
    }
}
